<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\MobileApp\\Providers\\MobileAppServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\MobileApp\\Providers\\MobileAppServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);