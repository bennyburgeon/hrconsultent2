<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Map\\Providers\\MapServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Map\\Providers\\MapServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);